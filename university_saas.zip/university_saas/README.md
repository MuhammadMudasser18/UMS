# University Management System — Multi-Tenant SaaS (Assignment 3)

A Django + Django REST Framework backend that lets multiple universities
("tenants") share one application instance and one database while keeping
their `Department` and `Student` data completely isolated from each other.

---

## 1. Architecture Overview

This project uses **shared database, shared schema, tenant-id column**
multi-tenancy (the "foreign-key" approach suggested in the assignment),
rather than schema-per-tenant. Every tenant-owned row lives in the same
`departments` / `students` tables, but carries a `university_id` foreign
key. Isolation is enforced entirely in the **application layer**, at two
points that every single request must pass through:

```
Request
   │
   ▼
TenantMiddleware            <- resolves & attaches request.tenant
   │                           (400 if it can't identify a tenant)
   ▼
TenantScopedModelViewSet    <- get_queryset() filters by request.tenant
   │                           perform_create() stamps university=request.tenant
   ▼
Response (only this tenant's data, ever)
```

Because both of these live in **one shared base class / one shared
middleware**, a developer adding a brand-new tenant-owned model in the
future only has to (a) subclass `TenantScopedModel` for the model and
(b) subclass `TenantScopedModelViewSet` for the view — isolation is
inherited "for free" and can't be forgotten on a per-view basis.

### Apps

| App       | Responsibility                                              |
|-----------|---------------------------------------------------------------|
| `tenants` | The `University` (tenant) model + `TenantMiddleware`         |
| `core`    | `Department` and `Student` models, serializers, viewsets     |

---

## 2. How the Current Tenant Is Identified

`tenants/middleware.py` implements **both** strategies described in the
assignment, tried in this order on every request:

1. **Approach B — Header (primary / what the tests & Postman collection use)**
   A required `X-Tenant-ID: <id>` HTTP header, where `<id>` is the
   `University`'s primary key.

   ```
   X-Tenant-ID: 1
   ```

2. **Approach A — Subdomain (fallback)**
   If no header is present, the middleware parses `request.get_host()`.
   For a host like `harvard.ourplatform.com`, it looks up
   `University.objects.get(subdomain="harvard")`. This means the exact
   same views/serializers/ViewSets work unmodified under either
   identification strategy — swapping strategies (or running both at
   once, e.g. header wins, subdomain is the fallback for browser traffic)
   requires touching only `middleware.py`.

If **neither** strategy resolves a tenant, or the resolved tenant has
`is_active=False`, the middleware returns `400`/`403` **before the
request ever reaches a view**. This is deliberate: it means there is no
code path where a Department/Student endpoint can run without a tenant
in scope. `/admin/` is exempted (Django admin manages `University` rows
themselves, so it can't require one).

---

## 3. How Data Isolation Is Enforced (Security)

Isolation is enforced by `core/views.py: TenantScopedModelViewSet`, the
common base class for `DepartmentViewSet` and `StudentViewSet`:

- **Reads (`list`, `retrieve`) — `get_queryset()` override**
  ```python
  def get_queryset(self):
      tenant = getattr(self.request, "tenant", None)
      if tenant is None:
          return self.queryset.none()
      return self.queryset.filter(university=tenant)
  ```
  DRF's generic `retrieve()`/`update()`/`destroy()` all call
  `get_object()`, which itself calls `get_queryset()` and then does
  `get_object_or_404()`. So requesting `/api/students/<id>/` for an
  object owned by a **different** tenant returns a plain **404**, not a
  403 — the API never even confirms that the object exists, which avoids
  leaking information to an attacker probing IDs.

- **Writes (`create`) — `perform_create()` override + read-only serializer field**
  ```python
  def perform_create(self, serializer):
      tenant = getattr(self.request, "tenant", None)
      serializer.save(university=tenant)
  ```
  The `university` field is marked `read_only_fields` on both
  serializers, so a client **cannot** set it via the POST/PATCH body even
  if they try (`{"university": 2, ...}` in the payload is silently
  ignored — the server-resolved tenant always wins). This satisfies the
  requirement that students are auto-assigned to the current tenant
  without the client specifying a University ID.

- **Cross-tenant relation guard — `StudentSerializer.validate_department()`**
  A more subtle leak vector: a Student's `department` FK could, in
  theory, be assigned to a `Department` that belongs to a *different*
  tenant than the Student itself (e.g. MIT admin linking a student to
  Harvard's "CS" department id). `validate_department()` explicitly
  checks `department.university_id == request.tenant.id` and rejects the
  request with `400` otherwise.

- **Per-tenant uniqueness, not global uniqueness**
  `Department.code` and `Student.roll_number` use
  `UniqueConstraint(fields=["university", "code/roll_number"])` instead
  of a plain `unique=True`. This lets Harvard and MIT both have a
  department coded `"CS"` or a student with roll number `"H001"` — as two
  independent tenants, they should never even be aware the other's IDs
  exist, let alone collide with them.

### What this protects against

| Attack                                                      | Result                          |
|---------------------------------------------------------------|----------------------------------|
| List `/api/students/` with another tenant's header            | Only your own tenant's rows      |
| `GET /api/students/<other-tenant-id>/`                         | `404 Not Found`                  |
| `PATCH`/`DELETE` another tenant's object by guessing its ID    | `404 Not Found`, nothing changes |
| `POST` with `"university": <other-tenant-id>` in the body      | Ignored; real tenant used instead|
| `POST` a Student linked to another tenant's `Department`       | `400`, rejected by serializer    |
| No `X-Tenant-ID` header / unknown tenant id / inactive tenant  | `400`/`403`, request never reaches a view |

---

## 4. Project Structure

```
university_saas/
├── config/                # Django project (settings, root urls)
├── tenants/
│   ├── models.py          # University model
│   ├── middleware.py      # TenantMiddleware (identifies request.tenant)
│   └── admin.py
├── core/
│   ├── models.py          # TenantScopedModel (abstract) -> Department, Student
│   ├── serializers.py     # DepartmentSerializer, StudentSerializer
│   ├── views.py           # TenantScopedModelViewSet -> DepartmentViewSet, StudentViewSet
│   ├── urls.py             # DRF router
│   └── tests.py           # Automated tenant-isolation test suite (9 tests)
├── requirements.txt
├── manage.py
└── postman_collection.json
```

---

## 5. Setup & Running

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python manage.py migrate
python manage.py createsuperuser  # optional, for /admin/

python manage.py runserver
```

Create your tenants (either via `/admin/` after creating a superuser, or
via the shell):

```bash
python manage.py shell -c "
from tenants.models import University
University.objects.create(name='Harvard University', subdomain='harvard')
University.objects.create(name='MIT', subdomain='mit')
"
```

Run the automated isolation test suite:

```bash
python manage.py test
```

---

## 6. API Reference

Base URL: `http://127.0.0.1:8000/api/`

Every endpoint below **requires** the `X-Tenant-ID` header (or a matching
subdomain host).

| Method | Endpoint                     | Description                        |
|--------|-------------------------------|-------------------------------------|
| GET    | `/api/departments/`           | List departments for current tenant |
| POST   | `/api/departments/`           | Create a department for current tenant |
| GET    | `/api/departments/<id>/`      | Retrieve (404 if owned by another tenant) |
| PUT/PATCH | `/api/departments/<id>/`   | Update (own tenant only)            |
| DELETE | `/api/departments/<id>/`      | Delete (own tenant only)            |
| GET    | `/api/students/`              | List students for current tenant    |
| POST   | `/api/students/`               | Create a student (tenant auto-assigned) |
| GET    | `/api/students/<id>/`         | Retrieve (404 if owned by another tenant) |
| PUT/PATCH | `/api/students/<id>/`      | Update (own tenant only)            |
| DELETE | `/api/students/<id>/`         | Delete (own tenant only)            |

`Student` payload fields: `first_name`, `last_name`, `email`,
`roll_number`, `department` (optional, must belong to the same tenant).
`university` is read-only / server-assigned on both resources.

---

## 7. Proving Isolation — curl Walkthrough

Assume `University` id `1` = Harvard, id `2` = MIT (seeded above).

```bash
BASE=http://127.0.0.1:8000/api

# 0. No tenant header at all -> rejected before it reaches a view
curl -s -o /dev/null -w "%{http_code}\n" $BASE/students/
# -> 400

# 1. Harvard creates a department
curl -s -X POST $BASE/departments/ \
  -H "X-Tenant-ID: 1" -H "Content-Type: application/json" \
  -d '{"name":"Computer Science","code":"CS"}'
# -> 201 {"id":1,"name":"Computer Science","code":"CS","university":1}

# 2. MIT creates a department with the SAME code -> allowed (isolated uniqueness)
curl -s -X POST $BASE/departments/ \
  -H "X-Tenant-ID: 2" -H "Content-Type: application/json" \
  -d '{"name":"Computer Science","code":"CS"}'
# -> 201 {"id":2,"name":"Computer Science","code":"CS","university":2}

# 3. Harvard creates a student, university is auto-assigned (not sent in body)
curl -s -X POST $BASE/students/ \
  -H "X-Tenant-ID: 1" -H "Content-Type: application/json" \
  -d '{"first_name":"Alice","last_name":"Smith","email":"alice@harvard.edu","roll_number":"H001","department":1}'
# -> 201 {"id":1, ..., "university":1}

# 4. MIT creates its own student
curl -s -X POST $BASE/students/ \
  -H "X-Tenant-ID: 2" -H "Content-Type: application/json" \
  -d '{"first_name":"Bob","last_name":"Jones","email":"bob@mit.edu","roll_number":"H001","department":2}'
# -> 201 {"id":2, ..., "university":2}    (same roll number as Alice - fine, different tenant)

# 5. Harvard lists students -> sees ONLY Alice
curl -s $BASE/students/ -H "X-Tenant-ID: 1"
# -> {"count":1, "results":[{"id":1,"first_name":"Alice", ...}]}

# 6. MIT lists students -> sees ONLY Bob
curl -s $BASE/students/ -H "X-Tenant-ID: 2"
# -> {"count":1, "results":[{"id":2,"first_name":"Bob", ...}]}

# 7. SECURITY TEST: MIT tries to fetch Harvard's student (id=1) directly
curl -s -o /dev/null -w "%{http_code}\n" $BASE/students/1/ -H "X-Tenant-ID: 2"
# -> 404 (object simply doesn't exist from MIT's point of view)

# 8. SECURITY TEST: MIT tries to attach a new student to Harvard's department (id=1)
curl -s -X POST $BASE/students/ \
  -H "X-Tenant-ID: 2" -H "Content-Type: application/json" \
  -d '{"first_name":"Eve","last_name":"Hacker","email":"eve@mit.edu","roll_number":"H999","department":1}'
# -> 400 {"department":["This department does not belong to the current tenant."]}

# 9. SECURITY TEST: MIT tries to smuggle a different university id in the body
curl -s -X POST $BASE/students/ \
  -H "X-Tenant-ID: 2" -H "Content-Type: application/json" \
  -d '{"first_name":"Mallory","last_name":"Attacker","email":"m@mit.edu","roll_number":"H998","university":1}'
# -> 201, but the created row's university is still MIT (2) - the field is server-controlled
```

A ready-to-import Postman collection with all of the above requests
(plus MIT/Harvard environment-style header presets) is included as
`postman_collection.json`.

---

## 8. Design Notes / Trade-offs

- **Why foreign-key instead of schema-per-tenant?** Simpler to set up,
  migrate, and reason about for an assignment of this scope; it's also
  the pattern explicitly recommended by the brief. The cost is that a
  single buggy `get_queryset()` could theoretically leak data — which is
  exactly why isolation is centralized in one reusable base class
  (`TenantScopedModelViewSet`) instead of being repeated per view.
- **404 instead of 403 for cross-tenant object access** is a deliberate
  security choice: it avoids confirming to a client that an object with
  that ID exists at all under a different tenant.
- **`AllowAny` permission** is used for simplicity/demo purposes (so the
  grader doesn't need to manage auth tokens on top of tenant headers).
  In a real deployment this would be `IsAuthenticated`, and the tenant
  would ideally also be cross-checked against the authenticated user's
  own tenant membership (not just a header anyone could set) — see
  "Next steps" below.
- **Next steps for production-hardening:** authenticate the tenant
  itself (e.g. signed API keys per university, or deriving the tenant
  from the authenticated user's own `user.university` instead of a
  trust-the-header approach), add per-tenant rate limiting, and consider
  Postgres row-level security as a second, database-level line of
  defense in addition to the application-level filtering above.
