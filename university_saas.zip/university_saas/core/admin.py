from django.contrib import admin

from .models import Department, Student


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "code", "university")
    list_filter = ("university",)
    search_fields = ("name", "code")


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ("id", "first_name", "last_name", "roll_number", "department", "university")
    list_filter = ("university", "department")
    search_fields = ("first_name", "last_name", "roll_number", "email")
