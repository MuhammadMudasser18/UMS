import json

from django.test import TestCase

from tenants.models import University
from core.models import Department, Student


class TenantIsolationTests(TestCase):
    def setUp(self):
        self.harvard = University.objects.create(name="Harvard University", subdomain="harvard")
        self.mit = University.objects.create(name="MIT", subdomain="mit")

        self.harvard_cs = Department.objects.create(
            university=self.harvard, name="Computer Science", code="CS"
        )
        self.mit_cs = Department.objects.create(
            university=self.mit, name="Computer Science", code="CS"
        )

        self.alice = Student.objects.create(
            university=self.harvard,
            department=self.harvard_cs,
            first_name="Alice",
            last_name="Smith",
            email="alice@harvard.edu",
            roll_number="H001",
        )
        self.bob = Student.objects.create(
            university=self.mit,
            department=self.mit_cs,
            first_name="Bob",
            last_name="Jones",
            email="bob@mit.edu",
            roll_number="H001",  # same roll number, different tenant -> allowed
        )

    def test_request_without_tenant_header_is_rejected(self):
        resp = self.client.get("/api/students/")
        self.assertEqual(resp.status_code, 400)

    def test_request_with_unknown_tenant_id_is_rejected(self):
        resp = self.client.get("/api/students/", HTTP_X_TENANT_ID="999")
        self.assertEqual(resp.status_code, 400)

    def test_list_only_returns_own_tenant_students(self):
        resp = self.client.get("/api/students/", HTTP_X_TENANT_ID=str(self.harvard.id))
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["results"][0]["id"], self.alice.id)

        resp = self.client.get("/api/students/", HTTP_X_TENANT_ID=str(self.mit.id))
        data = resp.json()
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["results"][0]["id"], self.bob.id)

    def test_cannot_fetch_other_tenants_object_by_id(self):
        # MIT trying to read Harvard's student by primary key -> 404, not 403,
        # so the existence of the object is not confirmed either.
        resp = self.client.get(f"/api/students/{self.alice.id}/", HTTP_X_TENANT_ID=str(self.mit.id))
        self.assertEqual(resp.status_code, 404)

        # Harvard can read its own student fine.
        resp = self.client.get(f"/api/students/{self.alice.id}/", HTTP_X_TENANT_ID=str(self.harvard.id))
        self.assertEqual(resp.status_code, 200)

    def test_create_stamps_current_tenant_automatically(self):
        payload = {
            "first_name": "Carol",
            "last_name": "White",
            "email": "carol@harvard.edu",
            "roll_number": "H002",
            "department": self.harvard_cs.id,
            # Even if a client tries to sneak in a different university id,
            # it must be ignored because the field is read-only.
            "university": self.mit.id,
        }
        resp = self.client.post(
            "/api/students/",
            data=json.dumps(payload),
            content_type="application/json",
            HTTP_X_TENANT_ID=str(self.harvard.id),
        )
        self.assertEqual(resp.status_code, 201)
        created = Student.objects.get(roll_number="H002")
        self.assertEqual(created.university_id, self.harvard.id)  # NOT mit.id

    def test_cannot_attach_student_to_other_tenants_department(self):
        payload = {
            "first_name": "Eve",
            "last_name": "Hacker",
            "email": "eve@mit.edu",
            "roll_number": "H999",
            "department": self.harvard_cs.id,  # belongs to Harvard, not MIT
        }
        resp = self.client.post(
            "/api/students/",
            data=json.dumps(payload),
            content_type="application/json",
            HTTP_X_TENANT_ID=str(self.mit.id),
        )
        self.assertEqual(resp.status_code, 400)
        self.assertIn("department", resp.json())

    def test_cannot_update_other_tenants_object(self):
        resp = self.client.patch(
            f"/api/students/{self.alice.id}/",
            data=json.dumps({"first_name": "Hacked"}),
            content_type="application/json",
            HTTP_X_TENANT_ID=str(self.mit.id),
        )
        self.assertEqual(resp.status_code, 404)
        self.alice.refresh_from_db()
        self.assertEqual(self.alice.first_name, "Alice")

    def test_cannot_delete_other_tenants_object(self):
        resp = self.client.delete(
            f"/api/students/{self.alice.id}/", HTTP_X_TENANT_ID=str(self.mit.id)
        )
        self.assertEqual(resp.status_code, 404)
        self.assertTrue(Student.objects.filter(id=self.alice.id).exists())

    def test_same_department_code_allowed_across_tenants(self):
        # Both Harvard and MIT have a department coded "CS" - proves
        # uniqueness constraints are scoped per-tenant, not global.
        self.assertEqual(Department.objects.filter(code="CS").count(), 2)
