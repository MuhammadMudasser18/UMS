from django.db import models

from tenants.models import University


class TenantScopedModel(models.Model):
    """
    Abstract base for every model that belongs to a tenant.

    Putting the `university` FK here (instead of repeating it on every
    model) means: (a) we can never forget to add tenant scoping to a new
    model, and (b) generic code (see core.views.TenantScopedModelViewSet)
    can filter on `university=` for *any* subclass.
    """

    university = models.ForeignKey(
        University, on_delete=models.CASCADE, related_name="%(class)ss"
    )

    class Meta:
        abstract = True


class Department(TenantScopedModel):
    name = models.CharField(max_length=255)
    code = models.CharField(max_length=20)

    class Meta:
        ordering = ["name"]
        # A department code only needs to be unique *within* a university -
        # Harvard and MIT can both have a department coded "CS".
        constraints = [
            models.UniqueConstraint(
                fields=["university", "code"], name="unique_department_code_per_university"
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.university.subdomain})"


class Student(TenantScopedModel):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    roll_number = models.CharField(max_length=50)
    department = models.ForeignKey(
        Department, on_delete=models.SET_NULL, null=True, blank=True, related_name="students"
    )
    enrolled_at = models.DateField(auto_now_add=True)

    class Meta:
        ordering = ["last_name", "first_name"]
        constraints = [
            models.UniqueConstraint(
                fields=["university", "roll_number"], name="unique_roll_number_per_university"
            )
        ]

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.university.subdomain})"
