from rest_framework.routers import DefaultRouter

from .views import DepartmentViewSet, StudentViewSet

router = DefaultRouter()
router.register(r"departments", DepartmentViewSet, basename="department")
router.register(r"students", StudentViewSet, basename="student")

urlpatterns = router.urls
