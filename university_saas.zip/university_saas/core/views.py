from rest_framework import permissions, viewsets
from rest_framework.exceptions import PermissionDenied

from .models import Department, Student
from .serializers import DepartmentSerializer, StudentSerializer


class TenantScopedModelViewSet(viewsets.ModelViewSet):
    """
    Base ViewSet enforcing tenant isolation for ANY tenant-owned model.

    THIS IS THE CORE SECURITY MECHANISM OF THE WHOLE ASSIGNMENT:

    - get_queryset() ALWAYS filters by request.tenant, set earlier by
      tenants.middleware.TenantMiddleware. There is no code path in this
      class that returns an un-filtered queryset, and no view below is
      allowed to override get_queryset() without still calling super().

    - perform_create() stamps `university=request.tenant` onto every new
      object automatically, so the tenant is derived server-side from the
      authenticated/identified request context - never trusted from the
      client's request body. Even if a malicious client includes
      "university": 2 in the POST payload, that field is read_only on the
      serializer (see serializers.py) and is overwritten here regardless.

    - get_object() relies on the tenant-filtered get_queryset(), so
      requesting /students/<id>/ for an object that belongs to a different
      tenant behaves exactly like it doesn't exist (404), never a 403 that
      would confirm the object's existence to an attacker.
    """

    permission_classes = [permissions.AllowAny]  # swap for IsAuthenticated + real auth in prod

    def get_queryset(self):
        tenant = getattr(self.request, "tenant", None)
        if tenant is None:
            # TenantMiddleware should have already rejected the request
            # before it got here, but we never trust that blindly - an
            # empty queryset is the safe default if a tenant is missing.
            return self.queryset.none()
        return self.queryset.filter(university=tenant)

    def perform_create(self, serializer):
        tenant = getattr(self.request, "tenant", None)
        if tenant is None:
            raise PermissionDenied("No tenant context available for this request.")
        serializer.save(university=tenant)

    def get_serializer_context(self):
        context = super().get_serializer_context()
        return context


class DepartmentViewSet(TenantScopedModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
    filterset_fields = ["code"]


class StudentViewSet(TenantScopedModelViewSet):
    queryset = Student.objects.select_related("department").all()
    serializer_class = StudentSerializer
    filterset_fields = ["department", "roll_number"]
