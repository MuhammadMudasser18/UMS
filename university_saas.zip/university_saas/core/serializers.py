from rest_framework import serializers

from .models import Department, Student


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        # `university` is deliberately NOT writable here - it is stamped on
        # automatically from request.tenant in perform_create(). Read-only
        # so it's still visible in responses, but a client can never set it.
        fields = ["id", "name", "code", "university"]
        read_only_fields = ["id", "university"]


class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = [
            "id",
            "first_name",
            "last_name",
            "email",
            "roll_number",
            "department",
            "enrolled_at",
            "university",
        ]
        read_only_fields = ["id", "enrolled_at", "university"]

    def validate_department(self, department):
        """
        Defence in depth: even though `department` choices come from the
        whole Department table by default, a Student must never be linked
        to a Department belonging to a *different* tenant than the one
        making the request. The request/tenant is pushed into the
        serializer context by the view (see TenantScopedModelViewSet).
        """
        if department is None:
            return department

        request = self.context.get("request")
        tenant = getattr(request, "tenant", None)

        if tenant is None or department.university_id != tenant.id:
            raise serializers.ValidationError(
                "This department does not belong to the current tenant."
            )
        return department
