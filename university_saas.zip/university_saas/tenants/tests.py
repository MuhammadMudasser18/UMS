# Tenant-isolation tests live in core/tests.py since they exercise the
# Department/Student endpoints end-to-end. This file is intentionally
# left as a placeholder for tests specific to University CRUD (e.g. via
# Django admin) should they be added later.
