from django.contrib import admin

from .models import University


@admin.register(University)
class UniversityAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "subdomain", "is_active", "created_at")
    search_fields = ("name", "subdomain")
