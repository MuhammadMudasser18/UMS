from django.db import models


class University(models.Model):
    """
    Represents a single tenant on the platform.

    Every piece of tenant-owned data (Department, Student, ...) carries a
    ForeignKey back to a University. This is the "shared database, shared
    schema, tenant-id column" style of multi-tenancy: cheap to run, easy to
    reason about, and enforced entirely in the application layer via
    tenants.middleware.TenantMiddleware + core.views.TenantScopedModelViewSet.
    """

    name = models.CharField(max_length=255, unique=True)
    # Used for the Approach A (subdomain) resolution strategy, e.g.
    # "harvard" -> harvard.ourplatform.com
    subdomain = models.SlugField(max_length=100, unique=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.subdomain})"
