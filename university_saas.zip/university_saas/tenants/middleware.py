from django.http import JsonResponse

from .models import University

# Paths that are allowed to be hit WITHOUT a resolved tenant.
# (Django admin manages tenants themselves, so it can't require one.)
TENANT_EXEMPT_PREFIXES = (
    "/admin",
    "/api/schema",
)

HEADER_NAME = "HTTP_X_TENANT_ID"  # corresponds to header "X-Tenant-ID"


class TenantMiddleware:
    """
    Resolves the current tenant (University) for every incoming request and
    attaches it to `request.tenant`.

    Two resolution strategies are supported, tried in this order:

    1. Approach B - Header (primary, used by the tests/Postman collection):
       A required `X-Tenant-ID: <id>` HTTP header containing the
       University's primary key.

    2. Approach A - Subdomain (secondary/bonus):
       If no header is supplied, the middleware falls back to parsing the
       request's Host header, e.g. `harvard.ourplatform.com` -> looks up
       University(subdomain="harvard"). This makes it trivial to swap the
       identification strategy, or support both simultaneously, without
       touching a single view.

    If neither strategy resolves a valid, active tenant, the middleware
    short-circuits the request with a 400 response *before* it ever reaches
    a view or a queryset - this is what guarantees that no view can
    accidentally run un-scoped and leak cross-tenant data.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path or ""

        if path.startswith(TENANT_EXEMPT_PREFIXES):
            request.tenant = None
            return self.get_response(request)

        tenant = self._resolve_from_header(request) or self._resolve_from_subdomain(request)

        if tenant is None:
            return JsonResponse(
                {
                    "detail": (
                        "Tenant could not be identified. Provide a valid "
                        "'X-Tenant-ID' header (a University id), or call the "
                        "API via a valid <subdomain>.ourplatform.com host."
                    )
                },
                status=400,
            )

        if not tenant.is_active:
            return JsonResponse(
                {"detail": f"Tenant '{tenant.name}' is not active."}, status=403
            )

        request.tenant = tenant
        return self.get_response(request)

    @staticmethod
    def _resolve_from_header(request):
        raw_id = request.META.get(HEADER_NAME)
        if raw_id is None:
            return None
        try:
            return University.objects.filter(pk=int(raw_id)).first()
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _resolve_from_subdomain(request):
        host = request.get_host().split(":")[0]  # strip port
        parts = host.split(".")
        # Expect something like harvard.ourplatform.com -> ["harvard", "ourplatform", "com"]
        if len(parts) < 3:
            return None
        subdomain = parts[0]
        if subdomain in ("www", "api"):
            return None
        return University.objects.filter(subdomain=subdomain).first()
